
const Footer = () => <footer>
    <div className="container">
        <p>&copy; {new Date().getFullYear()} Librairie XYZ</p>
    </div>
</footer>

export default Footer